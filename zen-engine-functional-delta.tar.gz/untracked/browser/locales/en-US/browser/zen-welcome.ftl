# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.

zen-welcome-title-line1 = Welcome to
zen-welcome-title-line2 = a calmer internet

zen-welcome-back = Back
zen-welcome-skip = Skip for now

zen-welcome-import-title = Bring your stuff along.
zen-welcome-import-description = Import your bookmarks, history and passwords from another browser and pick up right where you left off.
zen-welcome-import-yes = <strong>YES</strong>, import from another browser.
zen-welcome-import-no = <strong>NO</strong>, start fresh.

zen-welcome-default-browser-title = Make { -brand-short-name } your default?
zen-welcome-default-browser-description = Links from other apps will open in { -brand-short-name }. You can always change this later.
zen-welcome-set-default-browser = <strong>YES</strong>, make { -brand-short-name } default.
zen-welcome-dont-set-default-browser = <strong>NO</strong>, still exploring my options.

zen-welcome-default-search-title = Pick your search engine.
zen-welcome-default-search-description = Choose your default search engine. You can always change it later!

zen-welcome-essentials-title = Choose the apps you use most.
zen-welcome-essentials-description = Select your favorite apps to keep them handy in your sidebar.

zen-welcome-block-ads-title = Block ads and trackers?
zen-welcome-block-ads-description = { -brand-short-name } can install uBlock Origin for you, so pages load cleaner and faster. You can remove it any time.
zen-welcome-block-ads-yes = <strong>YES</strong>, block ads for me.
zen-welcome-block-ads-no = <strong>NO</strong>, show me everything.

zen-welcome-workspace-colors-title = Your space, your colors.
zen-welcome-workspace-colors-description = Personalize your browser by giving each space its own unique color identity.

zen-welcome-start-browsing-title = All set? Let’s get rolling!
zen-welcome-start-browsing-description-1 = You’re all set up and ready to go. Click the button below to start browsing with { -brand-short-name }.
zen-welcome-start-browsing = Dive in!
